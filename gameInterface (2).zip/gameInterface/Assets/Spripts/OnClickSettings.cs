using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnClickSettings : MonoBehaviour
{
    [SerializeField] GameObject panel1;
    [SerializeField] GameObject Button1;
    [SerializeField] GameObject Button2;

    public void OpenPanel()
    {
        if (panel1 != null)
        {
            panel1.SetActive(true);
            Button1.SetActive(false);
            Button2.SetActive(false);

        }
    }
}
