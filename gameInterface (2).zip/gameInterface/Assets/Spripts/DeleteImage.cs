using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DeleteImage : MonoBehaviour
{
       private void OnMouseDown()
        {
            Destroy(gameObject);
        }
    
}



    
