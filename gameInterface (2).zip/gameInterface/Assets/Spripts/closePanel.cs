using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class closePanel : MonoBehaviour
{

    [SerializeField] GameObject panel1;
    [SerializeField] GameObject Button1;
    [SerializeField] GameObject Button2;
   


    public void ClosePanel()
    {
        if (panel1 != null)
        {
            panel1.SetActive(false);
            Button1.SetActive(true);
            Button2.SetActive(true);
           
        }
    }
}
